from Population import Population

population = Population(700)
population.run()